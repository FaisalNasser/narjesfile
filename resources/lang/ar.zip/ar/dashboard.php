<?php

return array (
  '12_month' => 'هذا العام',
  '30_days' => 'اخر 30 يوم',
  '7_days' => 'هذا الاسبوع',
  'discount' => 'تخفيض',
  'last_pos_sales' => 'أخر عملية بيع',
  'product_name' => 'اسم المنتج',
  'sales' => 'المبيعات',
  'sales_date' => 'تاريخ الطلبات',
  'show' => 'اظهار',
  'status' => 'الحالة',
  'today' => 'اليوم',
  'top_10_items' => 'أفضل عشر منتجات مبيعاً',
  'total_amount' => 'الإجمالي',
  'total_sales' => 'إجمالي المبيعات',
  'yesterday' => 'أمس',
);
