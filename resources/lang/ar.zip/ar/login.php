<?php

return array (
  'login' => 'تسجيل الدخول',
  'login_text' => 'تسجيل الدخول الى لوحة التحكم',
);
