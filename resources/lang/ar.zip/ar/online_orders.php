<?php

return array (
  'all_orders' => 'كل الطلبات',
  'cancelled' => 'طلب ملغى',
  'completed' => 'طلب مكتمل',
  'new_orders' => 'طلب جديد',
  'order_board' => 'لوحة النظام',
  'order_detail' => 'تفاصيل الطلب',
  'order_home' => 'طلب توصيل',
  'order_store' => 'طلب في المطعم',
  'pending' => 'قيد الإنتظار',
);
