<?php

return array (
  'address' => 'العنوان',
);
