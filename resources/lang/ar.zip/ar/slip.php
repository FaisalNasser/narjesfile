<?php

return array (
  'back' => 'رجوع',
  'date' => 'التاريخ',
  'discount' => 'التخفيض',
  'grand_total' => 'الإجمالي',
  'invoice_no' => 'رقم الفاتورة',
  'menu' => 'منيو المطعم',
  'payment_with' => 'الدفع عبر',
  'qty' => 'الكمية',
  's_no' => 'S.No.',
  'tax' => 'الضريبة',
  'thanks_visting' => 'شكراً لزيارتكم',
  'time' => 'الوقت',
  'total' => 'الإجمالي',
  'total_given' => 'المجموع الكلي',
  'total_paid' => 'إجمالي الدفع',
  'unit_price' => 'سعر الوحدة',
  "cash" => "كاش",
	"card" => "كريديت كارد",
);
