<?php

return array (
  'last_12_month' => 'اخر 12 شهر',
  'last_30_days' => 'أخر 30 يوماً',
  'last_7_days' => 'اخر 7 ايام',
  'online_and_pos' => 'نقطة البيع والطلبات اونلاين',
  'online_orders' => 'لوحة الطلبات',
  'pos' => 'الكاشير',
);
